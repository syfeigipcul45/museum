// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('#dataTable').DataTable();
});

$(document).ready(function() {
  $('#dataTablePresentasi').DataTable();
});

$(document).ready(function() {
  $('#dataTableGambar').DataTable();
});

$(document).ready(function() {
  $('#dataTableVideo').DataTable();
});
