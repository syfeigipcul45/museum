

<?php $__env->startSection('title'); ?>
Berita
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section id="blog">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="blog_home clearfix">
                    <h1 class="text-center">Berita</h1>
                    <?php $__empty_1 = true; $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="blog_home_inner_main clearfix">
                        <div class="blog_home_inner clearfix aos-init aos-animate" data-aos="zoom-in-up">
                            <img src="<?php echo e($item->link_media); ?>" width="50%" height="25%" />
                        </div>
                        <div class="blog_home_inner_1 clearfix">
                            <h4>
                                Dibuat oleh <?php echo e($item->usersCreated->name); ?> pada <?php echo e($item->created_at); ?>

                            </h4>
                            <h2>
                                <a href="<?php echo e(route('homepage.berita.detail', $item->slug)); ?>" target="_blank"><?php echo e($item->title); ?></a>
                            </h2>
                            <p>
                                <?php echo shrinkText($item->content); ?>

                            </p>
                            <h4 class="heading_1">
                                <a href="<?php echo e(route('homepage.berita.detail', $item->slug)); ?>" target="_blank">Read More <i class="fa fa-arrow-right"></i></a>
                            </h4>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center">Data tidak ditemukan</div>
                    <?php endif; ?>

                    <div class="paginate clearfix text-center">
                        <ul class="pagination">
                            <?php echo e($berita->links('pagination::bootstrap-4')); ?>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('homepage.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\museum\resources\views/homepage/berita/index.blade.php ENDPATH**/ ?>