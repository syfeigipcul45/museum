

<?php $__env->startSection('title'); ?>
<?php echo e($berita->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section id="blog">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="blog_home clearfix">
                    <h1 class="text-center">Detail</h1>

                    <div class="blog_home_inner_main clearfix">
                        <div class="blog_home_inner clearfix aos-init aos-animate" data-aos="zoom-in-up">
                            <img src="<?php echo e($berita->link_media); ?>" width="60%" height="30%">
                        </div>
                        <div class="blog_home_inner_1 clearfix">
                            <h4>
                                Dibuat oleh <?php echo e($berita->usersCreated->name); ?> pada <?php echo e($berita->created_at); ?>

                            </h4>
                            <h2><?php echo e($berita->title); ?></h2>
                            <p><?php echo $berita->content; ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('homepage.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\museum\resources\views/homepage/berita/detail.blade.php ENDPATH**/ ?>