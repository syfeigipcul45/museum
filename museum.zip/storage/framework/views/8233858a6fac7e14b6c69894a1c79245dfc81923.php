<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title'); ?> | Museum Mulawarman</title>
    <link href="<?php echo e(getPengaturan()->favicon ?? ''); ?>" rel="icon">
    <link href="<?php echo e(asset('_homepage/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('_homepage/css/style.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('_homepage/css/font-awesome.min.css')); ?>" />
    <link href="<?php echo e(asset('_homepage/css/aos.css')); ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
    <link href="<?php echo e(asset('_homepage/css/element.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('_homepage/js/jquery-2.1.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('_homepage/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('_homepage/js/aos.js')); ?>"></script>
    <script src="<?php echo e(asset('_homepage/js/jquery-3.5.1.min.js')); ?>"></script>

    <style>
        @media (min-width: 768px) {
            .dropdown:hover .dropdown-menu {
                display: block;
                margin-top: 0;
            }
        }

        @media (max-width: 767px) {
            .dropdown:hover .dropdown-menu {
                display: none;
                margin-top: auto;
            }
        }
    </style>

    <?php echo $__env->yieldContent('extra-css'); ?>

</head>

<body>
    <?php echo $__env->make('homepage.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('homepage.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <script src="<?php echo e(asset('_homepage/js/classie.js')); ?>"></script>
    <script src="<?php echo e(asset('_homepage/js/cbpAnimatedHeader.js')); ?>"></script>
    <script>
        AOS.init({
            duration: 1200,
        })
    </script>
    <?php echo $__env->yieldContent('extra-js'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\museum\resources\views/homepage/layouts/app.blade.php ENDPATH**/ ?>