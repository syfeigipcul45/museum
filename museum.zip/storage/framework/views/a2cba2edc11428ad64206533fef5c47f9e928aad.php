<div class="container my-auto">
    <div class="copyright text-center my-auto">
        <span>Copyright &copy; Your Website <?php echo date('Y') ?></span>
    </div>
</div><?php /**PATH C:\xampp\htdocs\museum\resources\views/dashboard/layouts/footer.blade.php ENDPATH**/ ?>