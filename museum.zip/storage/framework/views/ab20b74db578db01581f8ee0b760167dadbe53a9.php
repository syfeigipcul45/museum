

<?php $__env->startSection('title'); ?>
Ruang Pamer
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-css'); ?>
<style>
    .box {
        display: flex;
    }

    model-viewer {
        margin-left: auto;
        margin-right: auto;
    }
</style>
<script type="module" src="https://unpkg.com/@google/model-viewer/dist/model-viewer.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section id="gallery">
    <div class="container">
        <div class="row">
            <div class="gallery clearfix">
                <h1 class="text-center">Ruang Pamer</h1>
                <div class="gallery_inner clearfix">
                    <?php $__currentLoopData = $ruang_pamer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-4">
                        <div class="gallery_inner_1">
                            <div class="grid clearfix">
                                <figure class="effect-sadie">
                                    <model-viewer camera-controls alt="Model" src="<?php echo e($item->link_media); ?>"></model-viewer>
                                    <figcaption>
                                        <h2><?php echo e($item->name); ?></h2>
                                        <!-- <p>
                                            <?php echo getDeskripsi($item->deskripsi); ?>

                                        </p> -->
                                        <a href="<?php echo e(route('homepage.layanan.detail_ruang_pamer', $item->slug)); ?>" target="__blank">View more</a>
                                    </figcaption>
                                </figure>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="paginate clearfix text-center">
                    <ul class="pagination">
                        <?php echo e($ruang_pamer->links('pagination::bootstrap-4')); ?>

                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('homepage.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\museum\resources\views/homepage/layanan/ruang_pamer.blade.php ENDPATH**/ ?>