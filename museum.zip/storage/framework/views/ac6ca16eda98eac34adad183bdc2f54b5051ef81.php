

<?php $__env->startSection('title'); ?>
Management Ruang Pamer
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-css'); ?>
<link href="<?php echo e(asset('_dashboard/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header d-flex align-items-center justify-content-between py-3">
        <h6 class="m-0 font-weight-bold text-primary">Daftar Submenu</h6>
        <a href="<?php echo e(route('dashboard.profil.create')); ?>" class="btn btn-primary btn-icon-split">
            <span class="icon text-white-50">
                <i class="fas fa-plus"></i>
            </span>
            <span class="text">Tambah Data</span>
        </a>
    </div>
    <div class="card-body">
        <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session('error')); ?>

        </div>
        <?php endif; ?>
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Submenu</th>
                        <th>Gambar</th>
                        <th>Deskripsi</th>
                        <th>Urutan</th>
                        <th>Ubah Urutan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>No</th>
                        <th>Submenu</th>
                        <th>Gambar</th>
                        <th>Deskripsi</th>
                        <th>Urutan</th>
                        <th>Ubah Urutan</th>
                        <th>Aksi</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php $__currentLoopData = $profil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$key); ?>.</td>
                        <td><?php echo e($item->submenu); ?></td>
                        <td><img src="<?php echo e($item->link_media); ?>" width="20%" height="20%"></td>
                        <td><?php echo e(Str::limit(strip_tags($item->deskripsi,'/<([a-z][a-z0-9]*)[^>]*?(\/?)>/si'), 50)); ?></td>
                        <td><?php echo e($item->urutan); ?></td>
                        <td>
                            <div class="btn-group">
                                <form action="<?php echo e(route('dashboard.profil.increase', $item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-info"><i class="fa fa-arrow-up"></i></button>
                                </form>
                                <form action="<?php echo e(route('dashboard.profil.decrease', $item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-arrow-down"></i></button>
                                </form>
                            </div>
                        </td>
                        <td class="text-center">
                            <a href="<?php echo e(route('dashboard.profil.show', $item->id)); ?>" class="btn btn-info btn-circle btn-sm">
                                <i class="fas fa-eye"></i>
                            </a>
                            <a href="<?php echo e(route('dashboard.profil.edit', $item->id)); ?>" class="btn btn-warning btn-circle btn-sm">
                                <i class="fas fa-pencil-alt"></i>
                            </a>
                            <a href="#" class="btn btn-danger btn-circle btn-sm remove-profil" data-toggle="modal" data-target="#deleteModal" data-href="<?php echo e(route('dashboard.profil.destroy', $item->id)); ?>">
                                <i class="fas fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<!-- Delete Modal-->
<?php echo $__env->make('dashboard.profil.includes.modal-delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('extra-js'); ?>
<!-- Page level plugins -->
<script src="<?php echo e(asset('_dashboard/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('_dashboard/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('_dashboard/js/demo/datatables-demo.js')); ?>"></script>

<!-- Custom scripts -->
<script>
    $('.remove-profil').click(function() {
        const hrefRemove = $(this).data('href');
        $('#remove-profil').attr('action', hrefRemove);
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\museum\resources\views/dashboard/profil/index.blade.php ENDPATH**/ ?>