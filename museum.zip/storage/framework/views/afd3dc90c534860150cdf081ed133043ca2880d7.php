

<?php $__env->startSection('title'); ?>
Management Ruang Pamer
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-css'); ?>
<link href="<?php echo e(asset('_dashboard/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header d-flex align-items-center justify-content-between py-3">
        <h6 class="m-0 font-weight-bold text-primary">Daftar Ruang Pamer</h6>
        <a href="<?php echo e(route('dashboard.ruang_pamer.create')); ?>" class="btn btn-primary btn-icon-split">
            <span class="icon text-white-50">
                <i class="fas fa-plus"></i>
            </span>
            <span class="text">Tambah Data</span>
        </a>
    </div>
    <div class="card-body">
        <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Gambar 3D</th>
                        <th>Deskripsi</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                    <th>No</th>
                        <th>Nama Gambar 3D</th>
                        <th>Deskripsi</th>
                        <th>Aksi</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php $__currentLoopData = $ruang_pamers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$key); ?>.</td>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo shrinkText($item->deskripsi); ?></td>
                        <td class="text-center">
                            <a href="<?php echo e(route('dashboard.ruang_pamer.show', $item->id)); ?>" class="btn btn-info btn-circle btn-sm">
                                <i class="fas fa-eye"></i>
                            </a>
                            <a href="<?php echo e(route('dashboard.ruang_pamer.edit', $item->id)); ?>" class="btn btn-warning btn-circle btn-sm">
                                <i class="fas fa-pencil-alt"></i>
                            </a>
                            <a href="#" class="btn btn-danger btn-circle btn-sm remove-pamer" data-toggle="modal" data-target="#deleteModal" data-href="<?php echo e(route('dashboard.ruang_pamer.destroy', $item->id)); ?>">
                                <i class="fas fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<!-- Delete Modal-->
<?php echo $__env->make('dashboard.layanan.ruang_pamer.includes.modal-delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('extra-js'); ?>
<!-- Page level plugins -->
<script src="<?php echo e(asset('_dashboard/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('_dashboard/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('_dashboard/js/demo/datatables-demo.js')); ?>"></script>

<!-- Custom scripts -->
<script>
    $('.remove-pamer').click(function() {
        const hrefRemove = $(this).data('href');
        $('#remove-pamer').attr('action', hrefRemove);
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\museum\resources\views/dashboard/layanan/ruang_pamer/index.blade.php ENDPATH**/ ?>